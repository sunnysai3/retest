package com.cg.service;

import com.cg.bean.Bean;

public interface IHotelService {

	int addCustomerDetails(Bean bean);

	String validateRoom(int rnumber);

	Bean getDetailsbyId(int id);

	//boolean validatenumber(double mnumber);

}
