package com.cg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.Bean;
import com.cg.dao.Dao;
import com.cg.dao.IDao;

public class HotelService implements IHotelService {
static IDao dao=null;
String rtype=null;
	@Override
	public int addCustomerDetails(Bean bean) {
		// TODO Auto-generated method stub
		dao=new Dao();
		return dao.addCustomerDetails(bean);
	}
	@Override
	public String validateRoom(int rnumber) {
		// TODO Auto-generated method stub
		if(rnumber==101) {
			 rtype ="AC_SINGLE";
		}
		else if(rnumber==102) {
			 rtype ="AC_SINGLE";
		}
		else if(rnumber==103) {
			 rtype ="AC_DOUBLE";			
		}
		else if(rnumber==201) {
			 rtype="NONAC_SINGLR";
		}
			else if(rnumber==202) {
				 rtype="NONAC_SINGLE";
			}
				else if(rnumber==203) {
				rtype="NONAC_DOUBLE";
				}
				else {
					 rtype=null;
				}
		return rtype;
	}
	@Override
	public Bean getDetailsbyId(int id) {
		// TODO Auto-generated method stub
		dao=new Dao();
		return dao.getDetailsbyId(id);
	}
	/*@Override
	public boolean validatenumber(double mnumber) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("resources/log4j.properties");
		Pattern pattern = Pattern.compile("{1}[7-9][0-9]{9}");
	    Matcher matcher = pattern.matcher(mnumber);
	    if(matcher.matches()) {				
			return true;
	}*/

}
