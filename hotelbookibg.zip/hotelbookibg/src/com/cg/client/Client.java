package com.cg.client;

import java.util.Scanner;

import com.cg.bean.Bean;
import com.cg.bean.Roombooking;
import com.cg.service.HotelService;
import com.cg.service.IHotelService;

public class Client {
	static Scanner sc=null;
	static IHotelService ser=null;
	static boolean status=false;
	static boolean res1;
public static void main(String[] args) {
	 sc=new Scanner(System.in);
	 Roombooking b1=new Roombooking();
	ser=new HotelService();
	 System.out.println("******************");
	System.out.println("1) BOOK ROOM");
	System.out.println("2) view Booking status");
	System.out.println("3) exit");
	int choice=sc.nextInt();
	switch (choice) {
	case 1:
		System.out.println("enter customer name");
		String name=sc.next();
		System.out.println("enter email");
		String mail=sc.next();
		System.out.println("enter customer address");
		String address=sc.next();
		
		System.out.println("enter mobile number");
		double mnumber=sc.nextDouble();
   
		System.out.println("room no:");
		int rnumber=sc.nextInt();
		String rtype=ser.validateRoom(rnumber);
		
		Bean bean=new Bean(name,mail,address,mnumber,rnumber,rtype);
		int res=0;
		res=addCustomerDetails(bean);
		if(res>0) {
			System.out.println("your room has been successfully booked,your customer id is: "+res);
			status=true;
		}
		else {
			System.out.println("try again");
		}
		if(status=true) {
		b1.setStatus("Booked");
		}
		else {
			b1.setStatus("not booked");
		}
		b1.setRno(bean.getRno());
		b1.setRtype(bean.getRtype());
		System.out.println("customer id: "+res);
		System.out.println("customer name: "+bean.getCname());
		System.out.println("booking status: "+b1.getStatus());
		System.out.println("room no: "+bean.getRno());
		System.out.println("room type: "+bean.getRtype());
		
		break;
		
	case 2:
		System.out.println("enter id to display data");
		int id=sc.nextInt();
		Bean b=null;
		b=getDetailsbyId(id);
		System.out.println(b);
		break;
	case 3:
		System.exit(0);
		break;
	}
}
private static Bean getDetailsbyId(int id) {
	// TODO Auto-generated method stub
	ser=new HotelService();
	return ser.getDetailsbyId(id);
}
private static int addCustomerDetails(Bean bean) {
	// TODO Auto-generated method stub
	ser=new HotelService();
	return ser.addCustomerDetails(bean);
}
}
