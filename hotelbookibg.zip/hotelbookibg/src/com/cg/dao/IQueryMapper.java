package com.cg.dao;

public interface IQueryMapper {

	String insert_qry ="insert into customerDetails values(CustomerId_seq.nextval,?,?,?,?,?,?)";
	String id ="select customerid_seq.currval from dual";
	String ret = "select * from customerDetails where CUSTID=?";

}
