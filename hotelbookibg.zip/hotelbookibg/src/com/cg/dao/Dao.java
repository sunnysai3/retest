package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.Bean;
import com.cg.util.DBUtil;

public class Dao implements IDao {
	Connection conn=null;
	static int sta=0;
	static int id=0;
	 
	@Override
	public int addCustomerDetails(Bean bean) {
		// TODO Auto-generated method stub
		Logger logger = Logger.getRootLogger();
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DBUtil.getDbConnection();
		try
		{
		PreparedStatement pst=conn.prepareStatement(IQueryMapper.insert_qry);
		pst.setString(1,bean.getCname());
		pst.setString(2, bean.getMail());
		pst.setString(3, bean.getAddress());
		pst.setDouble(4,bean.getMobNumber());
	pst.setString(5,bean.getRtype());
		pst.setInt(6,bean.getRno());
		
		sta=pst.executeUpdate();
		} catch(SQLException e)
		{
			logger.error("exception"+e.getMessage());
			System.out.println(e.getMessage());
		}		
		try {
		
		PreparedStatement pst1=conn.prepareStatement(IQueryMapper.id);
		//pst1.setInt(1, bean.getId());
		ResultSet rs=pst1.executeQuery();
		//System.out.println(rs.getInt(1));
		if(rs.next())
		{
			id=rs.getInt(1);
		}
		} catch(SQLException e) {
			logger.error("exception"+e.getMessage());
			System.out.println(e.getMessage());
		}
		return id;
	}
	@Override
	public Bean getDetailsbyId(int id) {
		// TODO Auto-generated method stub
		Logger logger = Logger.getRootLogger();
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DBUtil.getDbConnection();
		 Bean be=null;
		 try
		 {
		PreparedStatement pst2=conn.prepareStatement(IQueryMapper.ret);
		pst2.setInt(1,id);
		ResultSet rs=pst2.executeQuery();
		while(rs.next())
		{
			System.out.println(rs.getString(3));
			be=new Bean(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),
					rs.getDouble(5),rs.getInt(6),rs.getString(7));
		}
		 }
		catch(SQLException e)
		 {
			logger.error("exception"+e.getMessage());
			 System.out.println(e.getMessage());
		 }
		return be;
	}
}

