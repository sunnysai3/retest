package com.cg.dao;

import com.cg.bean.Bean;

public interface IDao {

	int addCustomerDetails(Bean bean);

	Bean getDetailsbyId(int id);

}
