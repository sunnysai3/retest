package com.cg.bean;

public class Roombooking {
private Bean bean;
private int rno;
private String rtype;
private String status;
public Bean getBean() {
	return bean;
}
public void setBean(Bean bean) {
	this.bean = bean;
}
public int getRno() {
	return rno;
}
public void setRno(int rno) {
	this.rno = rno;
}
public String getRtype() {
	return rtype;
}
public void setRtype(String rtype) {
	this.rtype = rtype;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}

}
