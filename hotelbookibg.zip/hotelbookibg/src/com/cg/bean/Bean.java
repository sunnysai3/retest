package com.cg.bean;

public class Bean {
	private int id;
private String cname;
private String mail;
private String address;
private double mobNumber;
private int rno;
private String rtype;


public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getMail() {
	return mail;
}
public void setMail(String mail) {
	this.mail = mail;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public double getMobNumber() {
	return mobNumber;
}
public void setMobNumber(double mobNumber) {
	this.mobNumber = mobNumber;
}
public int getRno() {
	return rno;
}
public void setRno(int rno) {
	this.rno = rno;
}
public String getRtype() {
	return rtype;
}
public void setRtype(String rtype) {
	this.rtype = rtype;
}

public Bean(int id, String cname, String mail, String address, double mobNumber, int rno, String rtype) {
	super();
	this.id = id;
	this.cname = cname;
	this.mail = mail;
	this.address = address;
	this.mobNumber = mobNumber;
	this.rno = rno;
	this.rtype = rtype;
}
public Bean(String cname, String mail, String address, double mobNumber, int rno, String rtype) {
	super();
	this.cname = cname;
	this.mail = mail;
	this.address = address;
	this.mobNumber = mobNumber;
	this.rno = rno;
	this.rtype = rtype;
}
@Override
public String toString() {
	return "Bean [id=" + id + ", cname=" + cname + ", mail=" + mail + ", address=" + address + ", mobNumber="
			+ mobNumber + ", rno=" + rno + ", rtype=" + rtype + "]";
}


}
