package com.cg.exception;

public class HotelException {

	public HotelException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
