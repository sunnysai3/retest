package com.cg.test;

import org.junit.Assert;

import com.cg.util.DBUtil;
import org.junit.Test;

public class JTest {
	@Test
	public void databaseConnectionCheck() {
		DBUtil db = new DBUtil();
		Assert.assertNotNull(db);
	}
	/*@Test
	public void insertCheck() {
		dao=new Dao();
		
	}
	*/
}
